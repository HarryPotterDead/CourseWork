<div class="products">
    <div class="product-item">
        <img src="https://html5book.ru/wp-content/uploads/2015/10/black-dress.jpg">
        <div class="product-list">
            <h3>Маленькое черное платье</h3>
            <span class="price">₽ 1999</span>
            <a href="" class="button">В корзину</a>
        </div>
    </div>

    <div class="product-item">
        <img src="https://html5book.ru/wp-content/uploads/2015/10/black-dress.jpg">
        <div class="product-list">
            <h3>Маленькое черное платье</h3>
            <span class="price">₽ 1999</span>
            <a href="" class="button">В корзину</a>
        </div>
    </div>

    <div class="product-item">
        <img src="">
        <div class="product-list">
            <h3>Маленькое черное платье</h3>
            <span class="price">₽ 1999</span>
            <a href="" class="button">В корзину</a>
        </div>
    </div>

    <div class="product-item">
        <img src="">
        <div class="product-list">
            <h3>Маленькое черное платье</h3>
            <span class="price">₽ 1999</span>
            <a href="" class="button">В корзину</a>
        </div>
    </div>
</div>