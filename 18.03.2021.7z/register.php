<div class="wrapper">
    <form action="index.php" class="form-signin" method="get">
        <h2 class="form-signin-heading">Please login</h2>
        <input type="hidden" name="registration" value="1" />
        <input type="text" class="form-control" name="login" placeholder="Login" required="" autofocus="">
        <input type="password" class="form-control" name="pasw" placeholder="Password" required="">
        <input type="text" class="form-control" name="name" placeholder="Name">
        <input type="text" class="form-control" name="email" placeholder="email">
        <input type="text" class="form-control" name="phone" placeholder="Phone">


        <button class="btn btn-lg btn-primary btn-block" type="submit">Зарегистрироваться</button>
    </form>
</div>