<div class="text">
  <p>Рамзес иконе дединсайдов, выйди в окно</p>
</div>
<video width="75%" height="42%" autoplay="" loop controls >
 <source src="/Assets/Video/HarryPotterDead.mp4" type='video/mp4; codecs="avc1.42E01E, mp4a.40.2"'>
</video>